<?php

class db
{
    public $connection;

    function __construct()
    {

        // automatically ths method will opendin
        $this->Open_method_db();
    }

    public function Open_method_db()
    {

        //   new mysqli  is assogned to $this->connection... and connect_errno is aproperty of new myqsqli

        $this->connection = new mysqli('localhost', 'id20429311_cms_db', 'cqA[icm-0q?5enV1', 'id20429311_lydiacms_db');
        // $this->connection...connect_errno id a property of new mysqli
        if ($this->connection->connect_errno) {

            die("Failed" . $this->connection->connect_error);
        }



    }

    public function query($sql)
    {

        $result = $this->connection->query($sql);

        $this->confirm_query($result);

        return $result;


    }

    private function confirm_query($result)
    {


        if (!$result) {

            die("Query Failed" . $this->connection->error);

        }

    }


    public function the_insert_id()
    {

        return $this->connection->insert_id;

    }
    public function fetch($string)
    {

        return mysqli_fetch_assoc($string);
    }



    public function escape_string($string)
    {


        $escaped_string = $this->connection->real_escape_string($string);

        return $escaped_string;


    }


    public static function checkRows($sql)
    {

        return mysqli_num_rows($sql);
    }

}



?>