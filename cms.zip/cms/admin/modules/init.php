<?php   

require_once('db.php');
require_once('posts.php');
require_once('auth.php');