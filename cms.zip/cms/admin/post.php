<?php session_start();  include("includes/header.php"); ?>
<div id="wrapper">


    <?php include("includes/nav.php") ?>
    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">
                        Create Post
                    </h1>
                    <ol class="breadcrumb">
                        <li>
                            <i class="fa fa-dashboard"></i> <a href="index.php">Dashboard</a>
                        </li>
                        <li class="active">
                            <i class="fa fa-file"></i> Create post
                        </li>
                    </ol>
                </div>
            </div>
            <!-- /.row -->

            <?php
            $posts = new Posts;
            if (isset($_POST['submit'])) {
                $title = $_POST['title'];
                $username = $_POST['username'];
                $desc = $posts->escape_string($_POST['desc']);
                $imagename = $_FILES['image']['name'];
                $iamgetype = $_FILES['image']['type'];
                $file_tmp = $_FILES['image']['tmp_name'];
                $foldername = "images/" . $imagename;
                move_uploaded_file($file_tmp, $foldername);
                $type = "BlogPosts";
                $status = 1;

                $db = new db;

                $username = $_SESSION['name'];


                $sql = " INSERT INTO tblposts(title ,image,username, body, type, status) ";
                $sql .= " VALUES('$title', '$imagename', '$username', '$desc', '$type', '$status')";
                $savePosts = $db->query($sql);
                if ($savePosts) {

                    echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Valid',
                        text:  'Posts created successfully'
                    })
                </script>";
                } else {

                    echo "<script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Invalid',
                        text:  'Unable to perform query'
                    })
                </script>";
                }
            }


            ?>




            <form action="" method="post" enctype='multipart/form-data'>

                <div class="form-group">
                    <label for="">Title</label>
                    <input type="text" name="title" class="form-control">
                </div>
                <div class="form-group">
                    <input type="hidden" name="username" class="form-control" value="<?php echo $_SESSION['name'] ?? "john doe" ?>">
                </div>

                <div class="form-group">
                    <label for="">Image</label>
                    <input type="file" name="image">
                </div>
                <div class="form-group">
                    <label for="">Description</label>
                    <textarea name="desc" id="" class="form-control" cols="30" rows="10"></textarea>
                </div>

                <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-primary p-0 m-0">Submit</button>
                </div>

            </form>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="js/jquery.js"></script>

<script src="js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.24/sweetalert2.all.js"></script>

<!-- Bootstrap Core JavaScript -->

</body>

</html>