
# About Project



 Project-Url [cms](localhost/cms)

During my time as a Backend intern developer at Fireswitch, I had the opportunity to guide students through the fundamentals of PHP all the way to project building.

In this project, I taught my student how to implement the following features.

1) Basic crude method
2) Image upload in PHP
3) Using joins in PHP
3) Using a session
4) Admin portal
5)Subscriber portal
5)Approve subscribers post by  admin
6) Fetching external API's [BONUS].
7) Pagination
etc.

# Project View.

![front-view](/cms_3.png)

# Stacks And Duration



```PHP

 -Front-end 

* [x] Html

* [x] Css

* [x] Boostrap



- Backend

* [x] PHP



# Project Duration.

 * [x] 3 month 15 days

 ```


